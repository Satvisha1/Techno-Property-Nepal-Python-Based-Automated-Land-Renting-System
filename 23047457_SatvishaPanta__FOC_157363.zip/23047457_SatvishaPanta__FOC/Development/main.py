from read import land_data_of_read
from write import land_data_of_write
from operation import rent, returns, available_land_for_rent
from datetime import datetime

def Greeting_Message():
    print("🤍" * 42)
    print("🤍\t Welcome to the Techno Property Land Rental Nepal\t\t🤍‍")
    print("🤍" * 42)
    print("🤍\t\t Swoyambhu, Kathmandu, Nepal\t\t\t\t🤍")
    print("🤍" * 42)
    print("🤍‍\t\t\t 9866041487\t\t\t\t\t🤍‍")
    print("🤍" * 42)
    print("🤍\t\t Hope you will have wonderful time here \t\t🤍")
    print("🤍" * 42)

Greeting_Message()

def main():
    txt_file = "property.txt"
    land = land_data_of_read(txt_file)

    while True:
        print("1. Show Available Land")
        print("2. Rent Available Land")
        print("3. Return Rented Land")
        print("4. Exit")

        preference = input("Enter your choice: ")
        #all available land for rend is displayed
        if preference == "1":
            available_land_for_rent(land)
        elif preference == "2":
            #handling renting process
            while True:
                customer_name = input("Enter Your Name: ")#asking user their input
                if not customer_name or customer_name.isspace() or customer_name.isdigit():
                    print("Invalid name. Please enter a valid string.")
                else:
                    break
            while True:
                try:
                    kitta_number = int(input("Enter Kitta Number: "))#asking for kitta num which user want to rent
                    rent(land, kitta_number, customer_name)
                    land_data_of_write(txt_file, land)
                    another_rent = input("Do you want to rent another land? (yes/no): ").lower()#asking user if they want to rent multiple land at same time
                    if another_rent != 'yes':
                        break
                except ValueError:
                    print("Invalid choice. Please enter a valid kitta number.")
        elif preference == "3":
            try:
                kitta_number = int(input("Enter Kitta Number: "))#asking for kitta num which user want to return
                returns(land, kitta_number)
                land_data_of_write(txt_file, land)
            except ValueError:#checking the input
                print("Invalid choice. Please enter a valid kitta number.")
        elif preference == "4":
            print("Thank you for your visit :)")#thank you message after exiting program
            break
        else:
            print("Invalid Choice. Please choose again.")

main()
