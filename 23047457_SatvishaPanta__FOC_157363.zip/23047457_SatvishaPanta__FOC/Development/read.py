def land_data_of_read(txt_file):
    land = [] #empty list to store data of land
    with open(txt_file, 'r') as record:
        for line in record:
            #removing white space
            start_index = 0
            while start_index < len(line) and line[start_index].isspace():
                start_index += 1

            end_index = len(line)
            while end_index > 0 and line[end_index - 1].isspace():
                end_index -= 1

            line = line[start_index:end_index]

            land_index = line.split(',')
            land.append({
                "kitta_number": int(land_index[0]),
                "city_district": land_index[1],
                "direction": land_index[2],
                "area": int(land_index[3]),
                "price": int(land_index[4]),
                "status": land_index[5]
            })
    return land
