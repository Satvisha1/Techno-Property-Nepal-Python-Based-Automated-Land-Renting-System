def land_data_of_write(txt_file, land):
    with open(txt_file, 'w') as record:
        for anna in land:
            data_line = str(anna['kitta_number']) + "," + \
                        anna['city_district'] + "," + \
                        anna['direction'] + "," + \
                        str(anna['area']) + "," + \
                        str(anna['price']) + "," + \
                        anna['status'] + "\n"
            record.write(data_line)

def write_rental_bill(anna, customer_name, rent_start_date, rented_duration, amount):
    with open("bill_of_rented_land.txt", 'a') as bill_file:
        bill_file.write("\n-------------------------- Bill -----------------------\n")
        bill_file.write("Kitta Number: " + str(anna['kitta_number']) + " \n")
        bill_file.write("Customer Name: " + customer_name + " \n")
        bill_file.write("Rent Start Date: " + rent_start_date.isoformat() + " \n")
        bill_file.write("Rent Duration (months): " + str(rented_duration) + " \n")
        bill_file.write("Amount: " + str(amount) + " NPR \n")
        bill_file.write("----------------------------------------------------------\n")

def write_return_bill(anna, return_date_time, extra_months, fine_charged, total_amount):
    with open("bill_of_returned_land.txt", 'a') as bill_file:
        bill_file.write("\n-------------------------- Bill -----------------------\n")
        bill_file.write("Kitta Number: " + str(anna['kitta_number']) + " \n")
        bill_file.write("Customer Name: " + anna['customer_name'] + " \n")
        bill_file.write("Rent Start Date: " + anna['rent_date_time'] + " \n")
        bill_file.write("Return Date: " + return_date_time.isoformat() + " \n")
        bill_file.write("Rent Duration (months): " + str(anna['rent_duration']) + " \n")
        bill_file.write("Extra Months: " + str(extra_months) + " \n")
        bill_file.write("Fine: " + str(fine_charged) + " NPR \n")
        bill_file.write("Total Amount: " + str(total_amount) + " NPR \n")
        bill_file.write("----------------------------------------------------------\n")
