from write import land_data_of_write, write_rental_bill, write_return_bill
from datetime import datetime, timedelta

def available_land_for_rent(land):
    try:
        available_land = [anna for anna in land if anna['status'] == "Available"]
        if not available_land:
            print("No Lands Available")
            return
        print("Available Lands:")
        for anna in available_land:
            print("Kitta Number: " + str(anna['kitta_number']))
            print("City District: " + anna['city_district'])
            print("Direction: " + anna['direction'])
            print("Area: " + str(anna['area']) + " square meters")
            print("Price: " + str(anna['price']) + " NPR")
            print("Status: " + anna['status'])
            print("---------------------")
    except Exception as e:
        print("Error:", e)

def rent(land, kitta_number, customer_name):
    try:
        total_amount = 0
        for anna in land:
            if anna['kitta_number'] == kitta_number and anna['status'] == "Available":
                anna['status'] = "Not Available"
                rent_start_date = datetime.now()

                while True:
                    try:
                        rented_duration = int(input("Enter the Rent Duration (in months): "))
                        if rented_duration <= 0:
                            print("Duration must be a positive integer.")
                        else:
                            break
                    except ValueError:
                        print("Invalid input. Please enter a valid number.")

                amount = anna['price'] * rented_duration
                total_amount = amount

                with open("rented_property.txt", 'a') as record:
                    record.write(
                        str(anna['kitta_number']) + "," +
                        anna['city_district'] + "," +
                        anna['direction'] + "," +
                        str(anna['area']) + "," +
                        customer_name + "," +
                        rent_start_date.isoformat() + "," +
                        str(rented_duration) + "," +
                        str(amount) + "\n"
                    )

                write_rental_bill(anna, customer_name, rent_start_date, rented_duration, amount)

                print("\n-------------------------- Bill -----------------------\n")
                print("Kitta Number: " + str(anna['kitta_number']) + " \n")
                print("Customer Name: " + customer_name + " \n")
                print("Rent Start Date: " + rent_start_date.isoformat() + " \n")
                print("Rent Duration (months): " + str(rented_duration) + " \n")
                print("Amount: " + str(amount) + " NPR \n")
                print("----------------------------------------------------------\n")
                print("Kitta Number " + str(kitta_number) + " has been Rented Successfully")
                print("\n----------------------------------------------------------\n")
                return total_amount
        print("Land Not Found")
    except Exception as e:
        print("Error:", e)

def returns(land, kitta_number):
    try:
        returned_lands = []
        with open("rented_property.txt", 'r') as record:
            for line in record:
                line = line.rstrip('\n')
                if not line:
                    continue
                rented_land_index = line.split(',')
                if len(rented_land_index) != 8:
                    print("Incorrect format in rented_property.txt:", line)
                    continue
                try:
                    returned_lands.append({
                        "kitta_number": int(rented_land_index[0]),
                        "city_district": rented_land_index[1],
                        "direction": rented_land_index[2],
                        "area": int(rented_land_index[3]),
                        "customer_name": rented_land_index[4],
                        "rent_date_time": rented_land_index[5],
                        "rent_duration": int(rented_land_index[6]),
                        "amount": int(rented_land_index[7])
                    })
                except ValueError as ve:
                    print("Error processing line:", line)
                    print("ValueError:", ve)
                    continue
            if not returned_lands:
                print("No Land Rented")
                return

        for anna in land:
            if anna['status'] == "Not Available" and anna['kitta_number'] == kitta_number:
                anna['status'] = "Available"
                land_data_of_write("property.txt", land)

        for anna in returned_lands:
            if anna["kitta_number"] == kitta_number:
                print("Customer Name Found: " + anna['customer_name'])

                while True:
                    try:
                        return_date_time_input = input("Enter the Return Date (YYYY-MM-DD): ")
                        return_date_time = datetime.strptime(return_date_time_input, "%Y-%m-%d")
                        break
                    except ValueError:
                        print("Please write the date in YYYY-MM-DD format.")

                rent_start_date = datetime.fromisoformat(anna['rent_date_time'])
                expected_return_date = rent_start_date + timedelta(days=anna['rent_duration'] * 30)

                extra_days = (return_date_time - expected_return_date).days
                extra_months = max(0, (extra_days + 29) // 30)

                monthly_rent = anna['amount'] / anna['rent_duration']
                fine_charged = 0.1 * monthly_rent * extra_months
                total_amount = anna['amount'] + (monthly_rent * extra_months) + fine_charged

                with open("return_property.txt", "a") as record:
                    record.write(
                        str(anna['kitta_number']) + "," +
                        anna['city_district'] + "," +
                        anna['direction'] + "," +
                        str(anna['area']) + "," +
                        anna['customer_name'] + "," +
                        anna['rent_date_time'] + "," +
                        return_date_time.isoformat() + "," +
                        str(anna['rent_duration']) + "," +
                        str(fine_charged) + "," +
                        str(total_amount) + "\n"
                    )

                write_return_bill(anna, return_date_time, extra_months, fine_charged, total_amount)

                print("\n-------------------------- Bill -----------------------\n")
                print("Kitta Number: " + str(anna['kitta_number']) + " \n")
                print("Customer Name: " + anna['customer_name'] + " \n")
                print("Rent Start Date: " + anna['rent_date_time'] + " \n")
                print("Return Date: " + return_date_time.isoformat() + " \n")
                print("Rent Duration (months): " + str(anna['rent_duration']) + " \n")
                print("Extra Months: " + str(extra_months) + " \n")
                print("Fine: " + str(fine_charged) + " NPR \n")
                print("Total Amount: " + str(total_amount) + " NPR \n")
                print("----------------------------------------------------------\n")
                print("Land with Kitta Number " + str(kitta_number) + " has been Returned Successfully")
                print("\n----------------------------------------------------------\n")
                break
    except Exception as e:
        print("Error:", e)
